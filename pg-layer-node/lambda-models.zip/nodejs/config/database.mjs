import { Sequelize } from 'sequelize';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

// Get current module path
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Load config based on environment
const env = process.env.NODE_ENV || 'development';
const configPath = path.join(__dirname, '../config/config.json');
const dbConfig = JSON.parse(fs.readFileSync(configPath, 'utf-8'))[env];

// Initialize Sequelize with enhanced configuration
const sequelize = new Sequelize({
  host: dbConfig.host,
  port: dbConfig.port,
  database: dbConfig.database,
  username: dbConfig.username,
  password: dbConfig.password,
  dialect: dbConfig.dialect,
  logging: process.env.SEQUELIZE_LOGGING === 'true' ? console.log : false,
  
  // SSL configuration
  dialectOptions: {
    ssl: {
      require: true,
      rejectUnauthorized: false,
    },
  },
  
  // Connection pool settings
  pool: {
    max: 5,
    min: 0,
    acquire: 30000,
    idle: 10000,
  },
  
  // Model definition defaults
  define: {
    freezeTableName: true,       // Prevent pluralization
    underscored: true,           // Use snake_case for columns
    timestamps: true,            // Enable createdAt/updatedAt
    paranoid: false,             // Disable soft deletes unless needed
    charset: 'utf8mb4',          // Support full Unicode
    collate: 'utf8mb4_unicode_ci',
  },
  
  // Additional PostgreSQL-specific options
  ...(dbConfig.dialect === 'postgres' && {
    native: true,                // Use native bindings
    application_name: 'my-app',  // Identify connections in PG
  }),
});

// Test connection on startup
(async () => {
  try {
    await sequelize.authenticate();
    console.log('Database connection established successfully');
    
    // Enable UUID extension if using PostgreSQL
    if (dbConfig.dialect === 'postgres') {
      await sequelize.query('CREATE EXTENSION IF NOT EXISTS "uuid-ossp"');
    }
  } catch (error) {
    console.error('Unable to connect to database:', error);
    process.exit(1);
  }
})();

// Export the configured instance
export default sequelize;